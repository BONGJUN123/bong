import discord
from discord.ext import commands
import sqlite3
import random
import asyncio
import json
import os
from datetime import datetime
from captcha.image import ImageCaptcha

intents = discord.Intents.all()
client = commands.Bot(intents=intents, command_prefix='g!')
token = 'ODM4NjA4ODQwMzMzMTk3MzEz.YI9lWA.yNAhnyLEVhsSh-NlsaM3VVrbs4U'
db = sqlite3.connect("folder/Money.db")
db_cur = db.cursor()
dev='개발자ㅣ봉준'
database = 'folder/guild.json'
excite = 'folder/excite.json'
patch_note = 'folder/patch_note.txt'
settings = 'folder/settings.json'

##########[아이디]
gun_id = 837952871080787999 #건의사항 채널 ID
admin_id = 837876715983994901 #개발자 ID
hong_id = 839732692684767274 #홍보채널 ID
role_id = 840089143706124320 #가입시 주는 Role
whitelist = 837876715983994901 #돈을 많이 주는 사람 ID

def get_bot_settings() -> dict:
    """
    봇 설정 파일을 파이썬 dict로 리턴합니다.
    """
    with open(settings, 'r', encoding="UTF-8") as f:
        return json.load(f)

async def is_Vip(ctx):
    """
    Cog 관련 명령어를 봇 소유자나 화이트리스트에 등록된 유저만 사용하게 만드는 코드입니다.
    """
    return ctx.author.id in get_bot_settings()["Vip"]

async def is_whitelisted(ctx):
    """
    Cog 관련 명령어를 봇 소유자나 화이트리스트에 등록된 유저만 사용하게 만드는 코드입니다.
    """
    return ctx.author.id in get_bot_settings()["whitelist"]

@client.event
async def on_ready():
    print('봇에 연결되었습니다: {}'.format(client.user.name))
    print('봇 아이디: {}'.format(client.user.id))
    while 1 :
        await client.change_presence(status=discord.Status.online, activity=discord.Game(f"g!도움말ㅣ개발자 : 봉준#5786"))
        await asyncio.sleep(5)
        await client.change_presence(status=discord.Status.online, activity=discord.Game(f"{str(len(client.guilds))} 개의 서버에서"))
        await asyncio.sleep(5)
        await client.change_presence(status=discord.Status.online, activity=discord.Game(f"{len(client.users)}명의 유저분들 과"))
        await asyncio.sleep(5)

@client.command()
async def 재산(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    embed=discord.Embed(title=f"아이디 : {data[0]}\n재산 : {data[1]} 달러", colour=0x2F3136)
    await ctx.channel.send(embed=embed)

@client.command()
async def 가입(ctx):
    if ctx.channel.id == 840055169244200960:
        db_cur.execute('INSERT INTO money VALUES (?, ?)', (ctx.author.id, 0))
        db.commit()
        gicho = random.randrange(3000)
        db_cur.execute(f"UPDATE money SET wallet = wallet + {gicho} WHERE id = {ctx.author.id}")
        db.commit()
        embed=discord.Embed(title=f"정상적으로 가입되었습니다. 기초 지원금으로 **{gicho}** 달러을 지급합니다. g!지원금으로 지달러금을 더 받으세요", colour=0x2F3136)
        await ctx.channel.send(embed=embed)
        role = discord.utils.get(ctx.guild.roles, id=role_id)
        await ctx.author.add_role(role)
    else:
        embed=discord.Embed(description='[디스코드 지달러서버](https://discord.gg/QExcvQ6KHM) 의 <#840055169244200960> 에서 g!가입으로 가입해주세요', colour=0x2F3136)
        await ctx.channel.send(embed=embed)

@client.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandOnCooldown):
        embed=discord.Embed(title=' 아직 쿨타임이 남았습니다  **{:.2f}초** 후에 다시 시도해주세요'.format(error.retry_after), colour=0x2F3136)
        await ctx.send(embed=embed)

@client.command()
@commands.cooldown(1,60,commands.BucketType.user)
async def 지원금(ctx):
    if ctx.author.bot:
        return
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    earnings = random.randrange(5000)
    db_cur.execute(f"UPDATE money SET wallet = wallet + {earnings} WHERE id = {ctx.author.id}")
    db.commit()
    embed=discord.Embed(title=f"기초 지원금으로 **{earnings}달러**을 지급했습니다", colour=0x2F3136)
    await ctx.channel.send(embed=embed)

@client.command()
async def 올인(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    dobak = random.choice([2,0])
    db_cur.execute(f"UPDATE money SET wallet = wallet * {dobak} WHERE id = {ctx.author.id}")
    db.commit()
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if dobak == 2:
        embed=discord.Embed(title="당신은 승리하였습니다", description=f'**{dobak}배**로 돈을 불렸으므로 현재 당신의 재산은 **{data[1]}달러** 입니다', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if dobak == 0:
        embed=discord.Embed(title="당신은 패배하였습니다", description=f'**{dobak}배**로 돈을 불렸으므로 현재 당신의 재산은 **{data[1]}달러** 입니다', colour=0x2F3136)
        await ctx.channel.send(embed=embed)

@client.command()
async def 도박(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    if data[1] < 100:
        embed=discord.Embed(title=f'당신의 돈은 현재 {data[1]}달러 입니다. {100 - data[1]}달러만큼의 돈을 더 벌어서 와주세요', colour=0x2F3136)
        await ctx.send(embed=embed)
        return
    black = random.choice([2,4,6,(1/2),(1/4),(1/6)])
    money = ctx.message.content[5:]
    earningive = money , black
    db_cur.execute(f"UPDATE money SET wallet = (wallet - {money}) + {money} * {black} WHERE id = {ctx.author.id}")
    db.commit()
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if black == (1/2):
        embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if black == (1/4):
        embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if black == (1/6):
        embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if black == 2:
        embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if black == 4:
        embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if black == 6:
        embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)

@client.command()
async def 파랑(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    blue = random.choice([0,2,4,6,100])
    db_cur.execute(f"UPDATE money SET wallet = (wallet - 10) + 10 * {blue} WHERE id = {ctx.author.id}")
    db.commit()
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if blue == 0:
        embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **10달러** 을 배팅하였습니다. 결과는 **{blue}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if blue == 2:
        embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **10달러** 을 배팅하였습니다. 결과는 **{blue}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if blue == 4:
        embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **10달러** 을 배팅하였습니다. 결과는 **{blue}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if blue == 6:
        embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **10달러** 을 배팅하였습니다. 결과는 **{blue}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if blue == 100:
        embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **10달러** 을 배팅하였습니다. 결과는 **{blue}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)

@client.command()
async def 반반(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    half = random.choice([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10])
    db_cur.execute(f"UPDATE money SET wallet = wallet * {half} WHERE id = {ctx.author.id}")
    db.commit()
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if half == 0:
        embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **전재산** 을 배팅하였습니다. 결과는 {half}배 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)
    if half == 2:
        embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **전재산** 을 배팅하였습니다. 결과는 {half}배 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
        await ctx.channel.send(embed=embed)

@client.command()
@commands.cooldown(1,1,commands.BucketType.user)
async def 노동(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    if ctx.channel.type is discord.ChannelType.private:
        db_cur.execute(f"UPDATE money SET wallet = wallet + 0.5 WHERE id = {ctx.author.id}")
        db.commit()
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        await ctx.send(f'당신은 0.5달러을 얻어 {data[1]}달러이 되었습니다')
    else:
        await ctx.send("도배를 방지하기 위해 DM채널에서만 사용해주세요")

@client.command()
async def 건의(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    if ctx.channel.type is discord.ChannelType.private:
        await ctx.send('건의글이 정상적으로 등록되었습니다')
        msg = ctx.message.content[5:]
        embed=discord.Embed(title=f'{ctx.guild.name}', colour=0x2F3136)
        embed.add_field(name=f'{ctx.author}', value=msg)
        embed.add_field(name="`서버 인원`", value=str(ctx.guild.member_count)+" 명", inline=True)
        embed.set_footer(text=dev)
        await client.get_channel(gun_id).send(embed=embed)
    else:
        await ctx.channel.send("신변 보호를 위해 DM채널에서 진행해주세요")

@client.command()
async def 서버정보(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    embed = discord.Embed(title=str(f"{ctx.guild} 서버의 정보"), colour=0x2F3136)
    embed.add_field(name="`서버 이름`", value=f"{ctx.guild}", inline=True)
    embed.add_field(name="`서버 아이디`", value=f"{ctx.guild.id}", inline=True)
    embed.add_field(name="`서버 생성일`", value=(ctx.guild.created_at), inline=True)
    embed.add_field(name="`서버 인원`", value=str(ctx.guild.member_count)+" 명", inline=True)
    await ctx.send(embed=embed)

@client.command()
async def 도움말(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    await ctx.send("DM채널을 확인해주세요")
    embed=discord.Embed(title='봇 도움말', description='[봇 초대하기](https://discord.com/api/oauth2/authorize?client_id=838608840333197313&permissions=0&scope=bot)', colour=0x2F3136)
    embed.set_footer(text=dev)
    embed1=discord.Embed(title='경제(도박)기능 관련 도움말', description='[봇 초대하기](https://discord.com/api/oauth2/authorize?client_id=838608840333197313&permissions=0&scope=bot)', colour=0x2F3136)
    embed1.add_field(name='지달러금 받기', value='g!지달러금 으로 최대 5000달러의 지달러금을 받으세요')
    embed1.add_field(name='노동하기', value='2초당 한번 DM채널에서 g!노동 이라는 명령어로 노동을 하여 0.5달러을 벌수 있습니다!')
    embed1.add_field(name='도박하기', value='g!도박 <금액> \ng!올인 \ng!반반 이라는 명령어로 당신의 재산을 불려보세요')
    embed1.add_field(name='재산 확인하기', value='g!재산 으로 당신의 재산을 확인하세요')
    embed1.set_footer(text=dev)
    embed2=discord.Embed(title='서버 관리기능 관련 도움말', description='[봇 초대하기](https://discord.com/api/oauth2/authorize?client_id=838608840333197313&permissions=0&scope=bot)', colour=0x2F3136)
    embed2.add_field(name='패치노트', value='g!패치노트 로 봇에게 추가된 능력을 확인해보세요')
    embed2.add_field(name='서버정보 확인', value='g!서버정보 로 서버의 정보를 확인해보세요!')
    embed2.set_footer(text=dev)
    await ctx.author.send(embed=embed)
    await ctx.author.send(embed=embed1)
    await ctx.author.send(embed=embed2)

@client.command()
async def 패치노트(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    fs = open(patch_note, 'r', encoding='UTF-8')
    lines = fs.readlines()
    i = lines[0]
    ii = lines[1]
    i = i.rstrip()
    embed = discord.Embed(title = f'v{i} 패치노트', description = ' ', color = 0x00FFFF, inline=False)
    embed.add_field(name = '업데이트 & 수정사항', value = f'{ii}')
    await ctx.send(embed=embed)

@client.command()
async def 패치노트등록(ctx, ver, *, update):
    if ctx.author.id == admin_id:
        with open(patch_note, 'a', encoding='UTF-8') as ff:
            ff.seek(0)
            ff.truncate()
            ff.write(ver + '\n')
            ff.write(update + '\n')
        await ctx.send(f'패치노트 등록 완료! \n버전은 `{ver}`이며, 업데이트 내용은 `{update}`입니다.')
    else:
        await ctx.send('> :no_entry_sign: 권한이 부족합니다.개발자만 사용이 가능합니다')

@client.command()
async def 제품목록(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    embed=discord.Embed(title='장터', descripion='어서오세요~!고객님~!')
    embed.add_field(name='봇 소스', value='**g!구매봇소스** 로 봇소스를 구매해보세요! 가격:400,000달러')
    embed.set_footer(text=f'당신의 재산 : {data[1]}')
    await ctx.channel.send(embed=embed)

@client.command()
async def 구매봇소스(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    if data[1] < 400000:
        embed=discord.Embed(title=f'당신의 돈은 현재 {data[1]}달러 입니다. {400000 - data[1]}달러만큼의 돈을 더 벌어서 와주세요', colour=0x2F3136)
        await ctx.send(embed=embed)
        return
    db_cur.execute(f"UPDATE money SET wallet = wallet - 400000 WHERE id = {ctx.author.id}")
    db.commit()
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    embed2=discord.Embed(title=f"당신은 봇소스를 구매하였습니다. 이용해주셔서 감사합니다.상품은 DM채널로 발송해드립니다. 당신의 현재 재산 : {data[1]}", colour=discord.Colour.blue())
    await ctx.channel.send(embed=embed2)
    embed1=discord.Embed(title='이용해주셔서 감사합니다', desription='다음에도 이용해주세요', colour=0x2F3136)
    embed1.add_field(name='상품명 : 봇소스', value='[다운로드](https://discord.gg/)')
    embed1.set_footer(text=f'구매후 당신의 재산 : {data[1]}')
    await ctx.author.send(embed=embed1)

@client.command()
async def 청소(ctx, amount=99999999):
    if ctx.author.guild_permissions.ban_members:
        await ctx.channel.purge(limit=amount)
        await ctx.channel.send("메시지 청소를 완료했습니다")
    else:
        await ctx.send(f'{ctx.author.mention}님은 권한이 없습니다')

@client.command()
@commands.cooldown(1,60 * 60,commands.BucketType.guild)
async def 홍보(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    if data == None:
        return await ctx.channel.send("먼저 가입해주세요")
    await ctx.send('홍보글이 정상적으로 등록되었습니다')
    msg = ctx.message.content[5:]
    embed=discord.Embed(title=f'{ctx.guild.name}', colour=0x2F3136)
    embed.add_field(name=f'{ctx.author}', value=msg)
    embed.set_footer(text=dev)
    await client.get_channel(hong_id).send(embed=embed)

@client.command()
@commands.check(is_whitelisted)
@commands.cooldown(1,60,commands.BucketType.user)
async def 돈내놔(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    bro = random.choice([10000, 100000, 1000000, 10000000])
    db_cur.execute(f"UPDATE money SET wallet = wallet + {bro} WHERE id = {ctx.author.id}")
    db.commit()
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    await ctx.channel.send(f"당신은 제가 사랑하는 봉준님이라서 {bro}달러 만큼의 돈을 주었어요! 이제 당신은 {data[1]}달러 만큼의 돈이 되었어요!")

@client.command()
@commands.check(is_Vip)
async def VIP(ctx):
    await ctx.channel.send("당신은 Vip가 맞습니다")

@client.command()
async def 버리기(ctx):
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    minus = ctx.ctx.content[6:]
    if data[1] < 10:
        await ctx.channel.send(f'당신은 {data[1]}달러 밖에 없군요.. 돈을 버리려면 최소 10달러 이상 있어야 합니다..')
    db_cur.execute(f"UPDATE money SET wallet = wallet - {minus} WHERE id = {ctx.author.id}")
    db.commit()
    db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
    data = db_cur.fetchone()
    await ctx.channel.send(f'당신은 {minus}달러을 버려서 {data[1]}달러이 있어요')

@client.command()
async def 슬로우(ctx):
    if ctx.author.guild_permissions.manage_channels:
        delay = ctx.message.content[6:]
        if delay.isalpha() == False:
            if int(float(str(delay))) > 21600:
                embed = discord.Embed(title = '채널 슬로우 타임 안내', description=f"{delay}초는 최대 시간의 범위 밖에 벗어났습니다.\n>>> 최대 21600초까지 설정 가능합니다.", colour=0x2F3136)
                embed.timestamp = datetime.utcnow()
                await ctx.channel.send(embed=embed)
            else:
                try:
                    await ctx.channel.edit(slowmode_delay=delay)
                except:
                    embed = discord.Embed(title = '채널 슬로우 타임 안내', description=f"명령어를 실행시킬 권한이 없습니다.", colour=0x2F3136)
                    embed.timestamp = datetime.utcnow()
                    await ctx.channel.send(embed=embed)
                else:
                    embed = discord.Embed(title='채널 슬로우 타임 안내', description=f"성공적으로 {delay} 초로 설정하였습니다.", colour=0x2F3136)
                    embed.timestamp = datetime.utcnow()
                    await ctx.channel.send(embed=embed)
        else:
            embed = discord.Embed(title='채널 슬로우 타임 안내', description=f"{delay} 은 제대로 된 숫자가 아닙니다.", colour=0x2F3136)
            embed.timestamp = datetime.utcnow()
            await ctx.channel.send(embed=embed)
    else:
        embed = discord.Embed(title='채널 슬로우 타임 안내', description=f"{ctx.author.name}, 명령어를 실행시킬 권한이 없습니다.", colour=0x2F3136)
        embed.timestamp = datetime.utcnow()
        await ctx.channel.send(embed=embed)

@client.command()
async def 인증설정(ctx):
    if ctx.author.guild_permissions.manage_channels:
        try:
            role = ctx.message.role_mentions[0].id
        except:
            embed = discord.Embed(title='인증설정',description=f"설정 가능한 역할이 없습니다.", colour=0x2F3136)
            embed.timestamp = datetime.utcnow()
            await ctx.reply(embed=embed)
            return
        
        with open(database, 'r') as f:
            data = json.loads(f.read())

        new_value = {'channel' : f'{ctx.channel.id}','guild' : f'{ctx.guild.id}','role' : f'{role}'}
        data[f'{ctx.channel.guild.id}'] = new_value

        with open(database, 'w') as f:
            f.write(json.dumps(data, sort_keys=True, indent=4, separators=(',', ': ')))

        embed = discord.Embed(title='인증설정', description=f'해당 채널 {ctx.channel.mention} 채널을 인증 채널로 설정하였습니다.', colour=0x2F3136)
        embed.timestamp = datetime.utcnow()
        await ctx.reply(embed=embed)
    else:
        embed=discord.Embed(title='오류', description=f'{ctx.author.mention}, 당신은 관리 권한이 없습니다', colour=0x2F3136)
        embed.timestamp = datetime.utcnow()
        await ctx.reply(embed=embed)

@client.command()
async def 인증(ctx):
    name = ctx.author.name
    data = json.loads(open(database).read())
    try:
        json_guild = data[f'{ctx.guild.id}']
    except: return

    if int(ctx.channel.id) == int(json_guild['channel']):
        a = ""
        Captcha_img = ImageCaptcha()
        for i in range(6):
            a += str(random.randint(0, 9))

        name = str(ctx.author. id) + ".png"
        Captcha_img.write(a, name)

        await ctx.channel.send(f"""{ctx.author.mention} 아래 숫자를 10초 내에 입력해주세요. """)
        await ctx.channel.send(file=discord.File(name))

        def check(msg):
            return msg.author == ctx.author and msg.channel == ctx.channel

        try:
            msg = await client.wait_for("message", timeout=10, check=check) # 제한시간 10초
        except:
            await ctx.channel.purge(limit=3)
            chrhkEmbed = discord.Embed(title='❌ 인증실패', color=0x2F3136)
            chrhkEmbed.add_field(name='닉네임', value=ctx.author, inline=False)
            chrhkEmbed.add_field(name='이유', value='시간초과', inline=False)
            await ctx.channel.send(embed=chrhkEmbed)
            return

        if msg.content == a:
            roless = (json_guild['role'])
            role = discord.utils.get(ctx.guild.roles, id=int(roless))
            await ctx.channel.purge(limit=4)
            tjdrhdEmbed = discord.Embed(title='인증성공', color=0x2F3136)
            tjdrhdEmbed.add_field(name='닉네임', value=ctx.author, inline=False)
            tjdrhdEmbed.add_field(name='3초후 인증역할이 부여됩니다.', value='** **', inline=False)
            tjdrhdEmbed.set_thumbnail(url=ctx.author.avatar_url)
            await ctx.channel.send(embed=tjdrhdEmbed)
            await asyncio.sleep(3)
            await ctx.author.add_roles(role)
        else:
            await ctx.channel.purge(limit=4)
            tlfvoEmbed = discord.Embed(title='❌ 인증실패', color=0x2F3136)
            tlfvoEmbed.add_field(name='닉네임', value=ctx.author, inline=False)
            tlfvoEmbed.add_field(name='이유', value='잘못된 숫자', inline=False)
            await ctx.channel.send(embed=tlfvoEmbed)


client.run(token)