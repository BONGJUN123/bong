import discord
from discord.ext import commands

class Chung(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command()
    async def 청소(self, ctx : commands.Context,  amount=99999999):
        if ctx.author.guild_permissions.ban_members:
            msg = ctx.message.content[5:]
            if int(float(str(msg))) > 99999999:
                await ctx.channel.send('최대 청소량은 99999999개 입니다.')
                return
            await ctx.channel.purge(limit=amount)
            await ctx.channel.send("메시지 청소를 완료했습니다")
        else:
            await ctx.send(f'{ctx.author.mention}님은 권한이 없습니다')

def setup(bot: commands.Bot):
    bot.add_cog(Chung(bot))
