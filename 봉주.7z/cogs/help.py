import discord
from discord.ext import commands
import sqlite3
import asyncio

class Help(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name='도움말', aliases=(['ㄷㅇㅁ','eda','ehdnaakf']))
    async def ehdnaak(self, ctx: commands.Context):
        intents = discord.Intents.all()
        client = commands.Bot(intents=intents, command_prefix='g!')
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        #one = "1️⃣"
        #two = "2️⃣"
        #three = "3️⃣"
        #four = "4️⃣"
        #emoji_list = [one, two]
        if data == None:
            await ctx.channel.send("먼저 가입해주세요")
            return
        await ctx.send("DM채널을 확인해주세요")
        embed=discord.Embed(title='봇 도움말', description='[봇 초대하기](https://discord.com/api/oauth2/authorize?client_id=838608840333197313&permissions=0&scope=bot)', colour=0x2F3136)
        embed.set_footer(text=dev)
        embed1=discord.Embed(title='경제(도박)기능 관련 도움말', description='[봇 초대하기](https://discord.com/api/oauth2/authorize?client_id=838608840333197313&permissions=0&scope=bot)', colour=0x2F3136)
        embed1.add_field(name='지원금 받기', value='g!지달러금 으로 최대 5000달러의 지원금을 받으세요')
        embed1.add_field(name='노동하기', value='2초당 한번 DM채널에서 g!노동 이라는 명령어로 노동을 하여 0.5달러을 벌수 있습니다!')
        embed1.add_field(name='도박하기', value='g!도박 <금액> \ng!올인 \ng!반반 이라는 명령어로 당신의 재산을 불려보세요')
        embed1.add_field(name='재산 확인하기', value='g!재산 으로 당신의 재산을 확인하세요')
        embed1.set_footer(text=dev)
        embed2=discord.Embed(title='서버 관리기능 관련 도움말', description='[봇 초대하기](https://discord.com/api/oauth2/authorize?client_id=838608840333197313&permissions=0&scope=bot)', colour=0x2F3136)
        embed2.add_field(name='패치노트', value='g!패치노트 로 봇에게 추가된 능력을 확인해보세요')
        embed2.add_field(name='서버정보 확인', value='g!서버정보 로 서버의 정보를 확인해보세요!')
        embed2.set_footer(text=dev)
        await ctx.author.send(embed=embed)
        await ctx.author.send(embed=embed1)
        await ctx.author.send(embed=embed2)

def setup(bot: commands.Bot):
    bot.add_cog(Help(bot))