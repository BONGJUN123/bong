import discord
from discord.ext import commands
import sqlite3
import random
import asyncio

class Dobak(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name='지원금', aliases=["ㅈㅇㄱ", "wdr", "자우원금"])
    @commands.cooldown(1,60,commands.BucketType.user)
    async def jiwon(self, ctx: commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        if ctx.author.bot:
            return
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        earnings = random.randrange(5000)
        db_cur.execute(f"UPDATE money SET wallet = wallet + {earnings} WHERE id = {ctx.author.id}")
        db.commit()
        embed=discord.Embed(title=f"기초 지원금으로 **{earnings}달러**을 지급했습니다", colour=0x2F3136)
        await ctx.channel.send(embed=embed)

    @commands.command(name='올인', aliases=['ㅇㅇ','dd','오린'])
    async def allin(self, ctx: commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        dobak = random.choice([2,0])
        db_cur.execute(f"UPDATE money SET wallet = wallet * {dobak} WHERE id = {ctx.author.id}")
        db.commit()
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if dobak == 2:
            embed=discord.Embed(title="당신은 승리하였습니다", description=f'**{dobak}배**로 돈을 불렸으므로 현재 당신의 재산은 **{data[1]}달러** 입니다', colour=0x2F3136)
            await ctx.channel.send(embed=embed)
        if dobak == 0:
            embed=discord.Embed(title="당신은 패배하였습니다", description=f'**{dobak}배**로 돈을 불렸으므로 현재 당신의 재산은 **{data[1]}달러** 입니다', colour=0x2F3136)
            await ctx.channel.send(embed=embed)

    @commands.command(name='가입', aliases=['ㄱㅇ','rd','rkdlq'])
    async def gadlq(self, ctx: commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {message.author.id}")
        data = db_cur.fetchone()
        if not data == None:
            return await message.channel.send("이미 가입하셨습니다")
        if ctx.channel.id == 840055169244200960:
            db_cur.execute('INSERT INTO money VALUES (?, ?)', (ctx.author.id, 0))
            db.commit()
            gicho = random.randrange(3000)
            db_cur.execute(f"UPDATE money SET wallet = wallet + {gicho} WHERE id = {ctx.author.id}")
            db.commit()
            embed=discord.Embed(title=f"정상적으로 가입되었습니다. 기초 지원금으로 **{gicho}** 달러을 지급합니다. g!지원금으로 지달러금을 더 받으세요", colour=0x2F3136)
            await ctx.channel.send(embed=embed)
        else:
            embed=discord.Embed(description='[디스코드 지원서버](https://discord.gg/QExcvQ6KHM) 의 <#840055169244200960> 에서 g!가입으로 가입해주세요', colour=0x2F3136)
            await ctx.channel.send(embed=embed)

    @commands.command(name='재산', aliases=['ㅈㅅ','wt','wotks'])
    async def wotk(self, ctx: commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        embed=discord.Embed(title=f"아이디 : {data[0]}\n재산 : {data[1]} 달러", colour=0x2F3136)
        await ctx.channel.send(embed=embed)

    @commands.command(name='도박', aliases=['ㄷㅂ','eq','ehqkr'])
    async def ehqk(self, ctx: commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        if data[1] < 100:
            embed=discord.Embed(title=f'당신의 돈은 현재 {data[1]}달러 입니다. {100 - data[1]}달러만큼의 돈을 더 벌어서 와주세요', colour=0x2F3136)
            await ctx.send(embed=embed)
            return
        black = random.choice([2,4,6,(1/2),(1/4),(1/6)])
        money = ctx.message.content[5:]
        earningive = money , black
        db_cur.execute(f"UPDATE money SET wallet = (wallet - {money}) + {money} * {black} WHERE id = {ctx.author.id}")
        db.commit()
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if black == (1/2):
            embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
            await ctx.channel.send(embed=embed)
        if black == (1/4):
            embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
            await ctx.channel.send(embed=embed)
        if black == (1/6):
            embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
            await ctx.channel.send(embed=embed)
        if black == 2:
            embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
            await ctx.channel.send(embed=embed)
        if black == 4:
            embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
            await ctx.channel.send(embed=embed)
        if black == 6:
            embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **{money}달러** 을 배팅하였습니다. 결과는 **{black}배** 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
            await ctx.channel.send(embed=embed)

    @commands.command(name='반반', aliases=['ㅂㅂ','ㅃ','qq'])
    async def qksqks(self, ctx: commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        half = random.choice([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10])
        db_cur.execute(f"UPDATE money SET wallet = wallet * {half} WHERE id = {ctx.author.id}")
        db.commit()
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if half == 0:
            embed=discord.Embed(title="당신은 패배하였습니다.", description=f'당신은 **전재산** 을 배팅하였습니다. 결과는 {half}배 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
            await ctx.channel.send(embed=embed)
        if half == 2:
            embed=discord.Embed(title="당신은 승리하였습니다.", description=f'당신은 **전재산** 을 배팅하였습니다. 결과는 {half}배 만큼 늘었습니다. 당신의 돈 : {data[1]}', colour=0x2F3136)
            await ctx.channel.send(embed=embed)

    @commands.command(name='노동', aliases=['ㄴㄷ','se','shehd'])
    async def shehdd(self, ctx: commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        if ctx.channel.type is discord.ChannelType.private:
            db_cur.execute(f"UPDATE money SET wallet = wallet + 0.5 WHERE id = {ctx.author.id}")
            db.commit()
            db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
            data = db_cur.fetchone()
            await ctx.send(f'당신은 0.5달러을 얻어 {data[1]}달러이 되었습니다')
        else:
            await ctx.send("도배를 방지하기 위해 DM채널에서만 사용해주세요")

    @commands.command(name='제품목록', aliases=['ㅈㅍㅁㄹ','wvaf','wpvnaahrfhr'])
    async def wpvna(self, ctx: commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        embed=discord.Embed(title='장터', descripion='어서오세요~!고객님~!')
        embed.add_field(name='봇 소스', value='**g!구매봇소스** 로 봇소스를 구매해보세요! 가격:400,000달러')
        embed.set_footer(text=f'당신의 재산 : {data[1]}')
        await ctx.channel.send(embed=embed)

    @commands.command(name='구매봇소스', aliases=['ravtt','tt','소스'])
    async def rnao(self, ctx: commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        if data[1] < 400000:
            embed=discord.Embed(title=f'당신의 돈은 현재 {data[1]}달러 입니다. {400000 - data[1]}달러만큼의 돈을 더 벌어서 와주세요', colour=0x2F3136)
            await ctx.send(embed=embed)
            return
        db_cur.execute(f"UPDATE money SET wallet = wallet - 400000 WHERE id = {ctx.author.id}")
        db.commit()
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        embed2=discord.Embed(title=f"당신은 봇소스를 구매하였습니다. 이용해주셔서 감사합니다.상품은 DM채널로 발송해드립니다. 당신의 현재 재산 : {data[1]}", colour=discord.Colour.blue())
        await ctx.channel.send(embed=embed2)
        embed1=discord.Embed(title='이용해주셔서 감사합니다', desription='다음에도 이용해주세요', colour=0x2F3136)
        embed1.add_field(name='상품명 : 봇소스', value='[다운로드](https://discord.gg/)')
        embed1.set_footer(text=f'구매후 당신의 재산 : {data[1]}')
        await ctx.author.send(embed=embed1)

def setup(bot: commands.Bot):
    bot.add_cog(Dobak(bot))