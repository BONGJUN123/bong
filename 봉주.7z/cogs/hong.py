import discord
from discord.ext import commands
import sqlite3

class Hong(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command()
    @commands.cooldown(1,60 * 60,commands.BucketType.guild)
    async def 홍보(self, ctx : commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        await ctx.send('홍보글이 정상적으로 등록되었습니다')
        msg = ctx.message.content[5:]
        embed=discord.Embed(title=f'{ctx.guild.name}', colour=0x2F3136)
        embed.add_field(name=f'{ctx.author}', value=msg)
        embed.set_footer(text=dev)
        await client.get_channel(837952871080787999).send(embed=embed)

def setup(bot: commands.Bot):
    bot.add_cog(Hong(bot))
