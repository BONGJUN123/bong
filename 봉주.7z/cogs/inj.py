import discord
from discord.ext import commands
import sqlite3
import random
import asyncio
import json
import os
from datetime import datetime
from captcha.image import ImageCaptcha

class Inj(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command()
    async def 인증설정(self, ctx : commands.Context):
        database = 'folder/guild.json'
        if ctx.author.guild_permissions.manage_channels:
            try:
                role = ctx.message.role_mentions[0].id
            except:
                embed = discord.Embed(title='인증설정',description=f"설정 가능한 역할이 없습니다.", colour=0x2F3136)
                embed.timestamp = datetime.utcnow()
                await ctx.reply(embed=embed)
                return
        
            with open(database, 'r') as f:
                data = json.loads(f.read())

            new_value = {'channel' : f'{ctx.channel.id}','guild' : f'{ctx.guild.id}','role' : f'{role}'}
            data[f'{ctx.channel.guild.id}'] = new_value

            with open(database, 'w') as f:
                f.write(json.dumps(data, sort_keys=True, indent=4, separators=(',', ': ')))

            embed = discord.Embed(title='인증설정', description=f'해당 채널 {ctx.channel.mention} 채널을 인증 채널로 설정하였습니다.', colour=0x2F3136)
            embed.timestamp = datetime.utcnow()
            await ctx.reply(embed=embed)
        else:
            embed=discord.Embed(title='오류', description=f'{ctx.author.mention}, 당신은 관리 권한이 없습니다', colour=0x2F3136)
            embed.timestamp = datetime.utcnow()
            await ctx.reply(embed=embed)

def setup(bot: commands.Bot):
    bot.add_cog(Inj(bot))