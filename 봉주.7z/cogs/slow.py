import discord
from discord.ext import commands
from datetime import datetime

class Slow(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command()
    async def 슬로우(self, ctx : commands.Context):
        if ctx.author.guild_permissions.manage_channels:
            delay = ctx.message.content[6:]
            if delay.isalpha() == False:
                if int(float(str(delay))) > 21600:
                    embed = discord.Embed(title = 'Discord', description=f"{delay}초는 최대 시간의 범위 밖에 벗어났습니다.\n>>> 최대 21600초까지 설정 가능합니다.", colour=0x2F3136)
                    embed.timestamp = datetime.utcnow()
                    await ctx.channel.send(embed=embed)
                else:
                    try:
                        await ctx.channel.edit(slowmode_delay=delay)
                    except:
                        embed = discord.Embed(title = 'Discord', description=f"명령어를 실행시킬 권한이 없습니다.", colour=0x2F3136)
                        embed.timestamp = datetime.utcnow()
                        await ctx.channel.send(embed=embed)
                    else:
                        embed = discord.Embed(title='Discord', description=f"성공적으로 {delay} 초로 설정하였습니다.", colour=0x2F3136)
                        embed.timestamp = datetime.utcnow()
                        await ctx.channel.send(embed=embed)
            else:
                embed = discord.Embed(title='Discord', description=f"{delay} 은 제대로 된 숫자가 아닙니다.", colour=0x2F3136)
                embed.timestamp = datetime.utcnow()
                await ctx.channel.send(embed=embed)
        else:
            embed = discord.Embed(title='Discord', description=f"{ctx.author.name}, 명령어를 실행시킬 권한이 없습니다.", colour=0x2F3136)
            embed.timestamp = datetime.utcnow()
            await ctx.channel.send(embed=embed)

def setup(bot: commands.Bot):
    bot.add_cog(Slow(bot))