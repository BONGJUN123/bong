import discord
from discord.ext import commands
import sqlite3

class Admin(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command()
    async def 건의(self, ctx : commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        if ctx.channel.type is discord.ChannelType.private:
            await ctx.send('건의글이 정상적으로 등록되었습니다')
            msg = ctx.message.content[5:]
            embed=discord.Embed(title=f'{ctx.guild.name}', colour=0x2F3136)
            embed.add_field(name=f'{ctx.author}', value=msg)
            embed.add_field(name="`서버 인원`", value=str(ctx.guild.member_count)+" 명", inline=True)
            embed.set_footer(text=dev)
            await client.get_channel(gun_id).send(embed=embed)
        else:
            await ctx.channel.send("신변 보호를 위해 DM채널에서 진행해주세요")

    @commands.command()
    async def 서버정보(self, ctx : commands.Context):
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        embed = discord.Embed(title=str(f"{ctx.guild} 서버의 정보"), colour=0x2F3136)
        embed.add_field(name="`서버 이름`", value=f"{ctx.guild}", inline=True)
        embed.add_field(name="`서버 아이디`", value=f"{ctx.guild.id}", inline=True)
        embed.add_field(name="`서버 생성일`", value=(ctx.guild.created_at), inline=True)
        embed.add_field(name="`서버 인원`", value=str(ctx.guild.member_count)+" 명", inline=True)
        await ctx.send(embed=embed)

def setup(bot: commands.Bot):
    bot.add_cog(Admin(bot))