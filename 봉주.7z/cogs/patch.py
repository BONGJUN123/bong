import discord
from discord.ext import commands
import sqlite3

class Patch(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command()
    async def 패치노트(self, ctx : commands.Context):
        patch_note = 'folder/patch_note.txt'
        admin_id = 837876715983994901 #개발자 ID
        db = sqlite3.connect("folder/Money.db")
        db_cur = db.cursor()
        dev='개발자ㅣ봉준'
        db_cur.execute(f"SELECT * FROM money WHERE id = {ctx.author.id}")
        data = db_cur.fetchone()
        if data == None:
            return await ctx.channel.send("먼저 가입해주세요")
        fs = open(patch_note, 'r', encoding='UTF-8')
        lines = fs.readlines()
        i = lines[0]
        ii = lines[1]
        i = i.rstrip()
        embed = discord.Embed(title = f'v{i} 패치노트', description = ' ', color = 0x00FFFF, inline=False)
        embed.add_field(name = '업데이트 & 수정사항', value = f'{ii}')
        await ctx.send(embed=embed)

    @commands.command()
    async def 패치노트등록(self, ctx : commands.Context, ver, *, update):
        if ctx.author.id == 837876715983994901:
            patch_note = 'folder/patch_note.txt'
            with open(patch_note, 'a', encoding='UTF-8') as ff:
                ff.seek(0)
                ff.truncate()
                ff.write(ver + '\n')
                ff.write(update + '\n')
            await ctx.send(f'패치노트 등록 완료! \n버전은 `{ver}`이며, 업데이트 내용은 `{update}`입니다.')
        else:
            await ctx.send('> :no_entry_sign: 권한이 부족합니다.개발자만 사용이 가능합니다')

def setup(bot: commands.Bot):
    bot.add_cog(Patch(bot))