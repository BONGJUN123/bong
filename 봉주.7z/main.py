import discord, aiofiles
from discord.ext import commands
import sqlite3
import random
import asyncio
import json
import os
from datetime import datetime
from captcha.image import ImageCaptcha
from pytz import timezone
from pprint import pprint

intents = discord.Intents.all()
client = commands.Bot(intents=intents, command_prefix='g!')
token = '토큰'
db = sqlite3.connect("folder/Money.db")
db_cur = db.cursor()
dev='개발자ㅣ봉준'
database = 'folder/guild.json' #유저 데이터 베이스 저장
excite = 'folder/excite.json' #입퇴장 로그 실패
patch_note = 'folder/patch_note.txt' #패치노트.txt 위치
settings = 'folder/settings.json' #화이트리스트 저장

##########[아이디]
gun_id = 837952871080787999 #건의사항 채널 ID
admin_id = 837876715983994901 #개발자 ID
role_id = 840089143706124320 #가입시 주는 Role
whitelist = 837876715983994901 #돈을 많이 주는 사람 ID

def get_bot_settings() -> dict:
    """
    봇 설정 파일을 파이썬 dict로 리턴합니다.
    """
    with open(settings, 'r', encoding="UTF-8") as f:
        return json.load(f)

async def is_Vip(ctx):
    """
    Cog 관련 명령어를 봇 소유자나 화이트리스트에 등록된 유저만 사용하게 만드는 코드입니다.
    """
    return ctx.author.id in get_bot_settings()["Vip"]

async def is_whitelisted(ctx):
    """
    Cog 관련 명령어를 봇 소유자나 화이트리스트에 등록된 유저만 사용하게 만드는 코드입니다.
    """
    return ctx.author.id in get_bot_settings()["whitelist"]

@client.event
async def on_ready():
    print('봇에 연결되었습니다: {}'.format(client.user.name))
    print('봇 아이디: {}'.format(client.user.id))
    while 1 :
        await client.change_presence(status=discord.Status.online, activity=discord.Streaming(name=f"g!도움말ㅣ개발자 : 봉준#5786", url='https://www.twitch.tv/bongradio'))
        await asyncio.sleep(5)
        await client.change_presence(status=discord.Status.online, activity=discord.Streaming(name=f"{str(len(client.guilds))} 개의 서버에서", url='https://www.twitch.tv/bongradio'))
        await asyncio.sleep(5)
        await client.change_presence(status=discord.Status.online, activity=discord.Streaming(name=f"{len(client.users)}명의 유저분들 과", url='https://www.twitch.tv/bongradio'))
        await asyncio.sleep(5)

@client.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandOnCooldown):
        embed=discord.Embed(title=' 아직 쿨타임이 남았습니다  **{:.2f}초** 후에 다시 시도해주세요'.format(error.retry_after), colour=0x2F3136)
        await ctx.send(embed=embed)

@client.command(name="cog", aliases=["cogs", "코그"])
@commands.check(is_whitelisted)
async def _cog_panel(ctx):
    """
    Cog를 로드하거나 언로드할 수 있는 명령어입니다.
    이모지 반응으로 컨트룔이 가능합니다.
    """
    load = "⏺"
    unload = "⏏"
    reload = "🔄"
    up = "⬆"
    down = "⬇"
    stop = "⏹"
    emoji_list = [load, unload, reload, up, down, stop]
    msg = await ctx.send("잠시만 기다려주세요...")
    for x in emoji_list:
        await msg.add_reaction(x)
    cog_list = [c.replace(".py", "") for c in os.listdir("./cogs") if c.endswith(".py")]
    cogs_dict = {}
    base_embed = discord.Embed(title=f"{client.user.name} Cog 관리 패널", description=f"`cogs` 폴더의 Cog 개수: {len(cog_list)}개", color=discord.Color.from_rgb(225, 225, 225))
    for x in cog_list:
        if x in [x.lower() for x in client.cogs.keys()]:
            cogs_dict[x] = True
        else:
            cogs_dict[x] = False
    cogs_keys = [x for x in cogs_dict.keys()]
    selected = cogs_keys[0]
    selected_num = 0

    def check(reaction, user):
        return user == ctx.author and str(reaction) in emoji_list and reaction.message.id == msg.id

    while True:
        tgt_embed = base_embed.copy()
        for k, v in cogs_dict.items():
            if k == selected:
                k = "▶" + k
            tgt_embed.add_field(name=k, value=f"상태: {'로드됨' if v else '언로드됨'}", inline=False)
        await msg.edit(content=None, embed=tgt_embed)
        try:
            reaction = (await client.wait_for("reaction_add", check=check, timeout=60))[0]
        except asyncio.TimeoutError:
            try:
                await msg.clear_reactions()
            except discord.Forbidden:
                [await msg.remove_reaction(x) for x in emoji_list]
            await msg.edit(content="Cog 관리 패널이 닫혔습니다.", embed=None)
            break
        if str(reaction) == down:
            if selected_num+1 == len(cogs_keys):
                wd = await ctx.send("이미 마지막 Cog 입니다.")
                await wd.delete(delay=3)
            else:
                selected_num += 1
                selected = cogs_keys[selected_num]
        elif str(reaction) == up:
            if selected_num == 0:
                wd = await ctx.send("이미 첫번째 Cog 입니다.")
                await wd.delete(delay=3)
            else:
                selected_num -= 1
                selected = cogs_keys[selected_num]
        elif str(reaction) == reload:
            if not cogs_dict[selected]:
                wd = await ctx.send("먼저 Cog를 로드해주세요.")
                await wd.delete(delay=3)
            else:
                client.reload_extension("cogs." + selected)
        elif str(reaction) == unload:
            if not cogs_dict[selected]:
                wd = await ctx.send("이미 Cog가 언로드되있습니다.")
                await wd.delete(delay=3)
            else:
                client.unload_extension("cogs." + selected)
                cogs_dict[selected] = False
        elif str(reaction) == load:
            if cogs_dict[selected]:
                wd = await ctx.send("이미 Cog가 로드되있습니다.")
                await wd.delete(delay=3)
            else:
                client.load_extension("cogs." + selected)
                cogs_dict[selected] = True
        elif str(reaction) == stop:
            await msg.clear_reactions()
            await msg.edit(content="Cog 관리 패널이 닫혔습니다.", embed=None)
            break
        try:
            await msg.remove_reaction(reaction, ctx.author)
        except discord.Forbidden:
            pass    

@client.command()
async def 인증(ctx):
    name = ctx.author.name
    data = json.loads(open(database).read())
    try:
        json_guild = data[f'{ctx.guild.id}']
    except: return

    if int(ctx.channel.id) == int(json_guild['channel']):
        a = ""
        Captcha_img = ImageCaptcha()
        for i in range(6):
            a += str(random.randint(0, 9))

        name = str(ctx.author. id) + ".png"
        Captcha_img.write(a, name)

        await ctx.channel.send(f"{ctx.author.mention}님 DM채널을 확인해주세요")

        await ctx.author.send(f"""{ctx.author.mention} 아래 숫자를 10초 내에 입력해주세요. """)
        await ctx.author.send(file=discord.File(name))

        def check(msg):
            return msg.author == ctx.author and msg.channel == ctx.channel

        try:
            msg = await client.wait_for("message", timeout=10, check=check) # 제한시간 10초
        except:
            await ctx.channel.purge(limit=3)
            chrhkEmbed = discord.Embed(title='❌ 인증실패', color=0x2F3136)
            chrhkEmbed.add_field(name='닉네임', value=ctx.author, inline=False)
            chrhkEmbed.add_field(name='이유', value='시간초과', inline=False)
            await ctx.author.send(embed=chrhkEmbed)
            return

        if msg.content == a:
            roless = (json_guild['role'])
            role = discord.utils.get(ctx.guild.roles, id=int(roless))
            await ctx.channel.purge(limit=4)
            tjdrhdEmbed = discord.Embed(title='인증성공', color=0x2F3136)
            tjdrhdEmbed.add_field(name='닉네임', value=ctx.author, inline=False)
            tjdrhdEmbed.add_field(name='3초후 인증역할이 부여됩니다.', value='** **', inline=False)
            tjdrhdEmbed.set_thumbnail(url=ctx.author.avatar_url)
            await ctx.author.send(embed=tjdrhdEmbed)
            await asyncio.sleep(3)
            await ctx.author.add_roles(role)
        else:
            await ctx.channel.purge(limit=4)
            tlfvoEmbed = discord.Embed(title='❌ 인증실패', color=0x2F3136)
            tlfvoEmbed.add_field(name='닉네임', value=ctx.author, inline=False)
            tlfvoEmbed.add_field(name='이유', value='잘못된 숫자', inline=False)
            await ctx.author.send(embed=tlfvoEmbed)
    else:
        embed=discord.Embed(title='❌ 인증실패', color=0x2F3136)
        embed.add_field(name='사유', value=f'이 채널에선 인증이 불가능합니다. 인증 가능한 채널에서 인증을 진행해주세요')
        await ctx.author.send(embed=embed)
        return

[client.load_extension(f"cogs.{x.replace('.py', '')}") for x in os.listdir("./cogs") if x.endswith('.py')]
client.run(token)